/* 
------------------
LOOP
------------------
1. Display "Ajke amar mon valo nei" for 39 times
2. Display numbers between 58 to 98
3. Show all even numbers from 412 to 456
4. Show all odd numbers 581 to 623
5. Difference between while loop and for loop
6. Declare an array for all the topics that you have learned last few days
display then as output
7. Create an array for all the mobile phones. Display all the elements of the array
by using a while loop
8. Run a loop from 30 to 86. this loop will stop if the values get higher than 44
9. Write the price of the books that you have. 
Display the prices if the prices is lower than 200

*/