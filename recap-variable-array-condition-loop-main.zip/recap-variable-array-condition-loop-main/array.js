/* 
---------------------
ARRAY
-----------------------
1. What is the purpose?
2. How to declare an array in JS
3. Number of elements in an Array
4. What is index? 
5. Find the value of an element by index
6. Change an element by index
7. get the index of an element by the value
8. what does it mean when you get undefined while getting the value of an element by index
9. How can you add an element to an array at the last position
10. How can you remove the last element from array
11. Add an element at the first position of an array
12. Remove the first element of an array
*/