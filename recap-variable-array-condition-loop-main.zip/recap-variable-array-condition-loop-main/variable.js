/* 
------------------
VARIABLE
-------------------
1. What is JavaScript?
2. How does JS Works?
3. What is Variable?
4. Declare a variable
5. Types of Variable? How can you find out type of a variable
6. Primitive and non-primitive data types
7. Naming Convention of JS variables
8. Math Operation +, -, *, /, %
9. Short hand: +=, -=, *=, /=
10. ++, --
11. parseInt, ParseFloat
12. toFixed
*/